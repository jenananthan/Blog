Adding sso-apps gadget.

1. Copy folder "sso-apps" to <IS_HOME>/repository/deployment/server/jaggeryapps/portal/gadgets 
2. Replace <IS_HOME>/repository/deployment/server/jaggeryapps/dashboard/apis/gadget.json with gadget.json
3. Replace <IS_HOME>/repository/deployment/server/jaggeryapps/dashboard/index.jag with index.jag


Creating service providers
1. When create the service provider in management console ,provide the app's login url in the description 
field between two $ signs

More detail on creating gadgets
1. AddingSSOgadget.pdf contains information on creating gadgets and implementation details of sso-apps gadget 




